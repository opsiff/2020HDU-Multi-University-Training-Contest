#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int main(void) {
  int T;
  scanf("%d", &T);
  while (T--) {
    int d;
    scanf("%*d%*d%d%*d", &d);
    printf("%d\n", d);
  }
  return 0;
}
