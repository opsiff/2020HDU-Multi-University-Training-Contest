#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 5e5 + 500;
const int mod = 1e9 + 7;

vector<string>str;

int main(){
    freopen();
}
